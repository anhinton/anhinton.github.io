library(testthat)
library(conduit)

test_check("conduit")
